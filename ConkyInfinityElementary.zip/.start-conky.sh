#!/bin/sh
sleep 
conky -d -c ~/.conkyrc
exit
