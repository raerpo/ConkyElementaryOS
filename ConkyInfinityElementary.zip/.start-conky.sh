#!/bin/sh
sleep 5
conky -d -c ~/.conkyrc
exit
